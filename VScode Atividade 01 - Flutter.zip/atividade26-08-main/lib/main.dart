import 'package:flutter/material.dart';
import 'meuApp.dart';

void main() {
  runApp(const MeuApp());
}

