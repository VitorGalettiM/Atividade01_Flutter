package com.example.atividade01

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
